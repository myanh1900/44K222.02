from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile
from django import forms

class CreateUserForm(UserCreationForm):
    email = forms.EmailField()
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class UserUpdateForm(forms.ModelForm):
    email = forms.EmailField()

    class Meta:
        model = User
        fields = ['username', 'email']
        
class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = '__all__'
        exclude = ['user', 'template']
        labels ={
            'name' : 'Họ và tên',
            'image': 'Ảnh đại diện',

            'birthday': 'Ngày sinh (ex: 2000-12-01)',
            'email': 'Email',
            'phone' : 'Điện thoại',
            'address': 'Địa chỉ',
            'facebook_url': 'URL Facebook (ex: www.facebook.com/moto0122/)',
            'linkedin_url': 'URL LinkedIn (ex: www.linkedin.com/moto0122/)',

            'interest': 'Sở thích',
            'language': 'Ngoại ngữ',

            'about': 'Giới thiệu bản thân ',
            'skills': 'Kỹ năng',
            'education': 'Học vấn',
            'experience': 'Kinh nghiệm làm việc',
            'services': 'Kinh nghiệm xã hội',
                    }

class updateTemplate(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['template']