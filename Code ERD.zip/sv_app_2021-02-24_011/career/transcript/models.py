from django.db import models
from django.urls import reverse
# from account.models import SinhVien
# Create your models here.
# Khóa học
class SchoolYear(models.Model):
    so_khoa = models.CharField(max_length=255, null=True, blank=True)
    def __str__(self):
        return self.so_khoa  

# Ngành học
class Major(models.Model):
    ten_nganh =  models.CharField(max_length=255, null=True, blank=True)
    def __str__(self):
        return self.ten_nganh

# Môn_Ngành
class SubjectMajor(models.Model):
    ten_mon_hoc = models.CharField(max_length=255, null=True, blank=True)
    id_khoa = models.ForeignKey(SchoolYear, null=True, on_delete=models.CASCADE)
    id_nganh = models.ForeignKey(Major, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return self.ten_mon_hoc

    def get_absolute_url(self):
        return reverse("subjectmajor-detail", kwargs={"pk": self.pk})

# Khóa_Ngành
class SchoolYearMajor(models.Model):
    ten_khoa_nganh = models.CharField(max_length=255,null=True,blank=True)
    id_khoa = models.ForeignKey(SchoolYear, null=True, on_delete=models.CASCADE)
    id_nganh = models.ForeignKey(Major, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return self.ten_khoa_nganh

    def get_absolute_url(self):
        return reverse("schoolyearmajor-detail", kwargs={"pk": self.pk})

# Chương trình đào tạo
class EducationProgram(models.Model):
    id_khoa = models.ForeignKey(SchoolYear, null=True, on_delete=models.CASCADE)
    id_nganh = models.ForeignKey(Major, null=True, on_delete=models.CASCADE)
    mon_hoc = models.CharField(max_length=255,null=True,blank=True)
    def __str__(self):
        return self.mon_hoc

    def get_absolute_url(self):
        return reverse("educationprogram-detail", kwargs={"pk": self.pk})
 
# Lớp học
class LopHoc(models.Model): 
    class_name = models.CharField(max_length=255,null=True,blank=True)
    ten_khoa_nganh = models.ForeignKey(SchoolYearMajor, null=True, on_delete=models.CASCADE)
    # sinh_vien = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return self.class_name

    def get_absolute_url(self):
        return reverse("class-detail", kwargs={"pk": self.pk})