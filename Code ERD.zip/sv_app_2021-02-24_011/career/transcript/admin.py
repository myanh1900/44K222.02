from django.contrib import admin
from .models import SchoolYear, Major, SubjectMajor, SchoolYearMajor, LopHoc, EducationProgram
# Register your models here.
admin.site.register(SchoolYear)
admin.site.register(Major)
admin.site.register(SubjectMajor)
admin.site.register(SchoolYearMajor)
admin.site.register(LopHoc)
admin.site.register(EducationProgram)