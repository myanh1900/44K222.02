from django.apps import AppConfig


class TranscriptConfig(AppConfig):
    name = 'transcript'
