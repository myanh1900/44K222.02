from django.forms import ModelForm

from .models import SubjectMajor, SchoolYearMajor, EducationProgram, LopHoc, SchoolYear, Major

class SubjectMajorForm(ModelForm):
    class Meta:
        model = SubjectMajor
        fields = '__all__'
        labels ={
            'ten_mon_hoc': 'Tên Môn Học',
            'id_khoa': 'Khóa Học',
            'id_nganh': 'Ngành Học',
                    }
class SubjectMajorUpdateForm(ModelForm):
    class Meta:
        model = SubjectMajor
        fields = '__all__'
        labels ={
            'ten_mon_hoc': 'Tên Môn Học',
            'id_khoa': 'Khóa Học',
            'id_nganh': 'Ngành Học',
                    }

class EducationProgramForm(ModelForm):
    class Meta:
        model = EducationProgram
        fields = '__all__'
        labels ={
            'mon_hoc': 'Tên Môn Học',
            'id_khoa': 'Khóa Học',
            'id_nganh': 'Ngành Học',
                    }
class EducationProgramUpdateForm(ModelForm):
    class Meta:
        model = EducationProgram
        fields = '__all__'
        labels ={
            'mon_hoc': 'Tên Môn Học',
            'id_khoa': 'Khóa Học',
            'id_nganh': 'Ngành Học',
                    } 

class SchoolYearMajorForm(ModelForm):
    class Meta:
        model = SchoolYearMajor
        fields = '__all__'
        labels ={
            'ten_khoa_nganh': 'Tên Khóa Ngành',
            'id_khoa': 'Khóa Học',
            'id_nganh': 'Ngành Học',
                    } 
class SchoolYearMajorUpdateForm(ModelForm):
    class Meta:
        model = SchoolYearMajor
        fields = '__all__'
        exclude= ('id_khoa', 'id_nganh',)
        labels ={
            'ten_khoa_nganh': 'Tên Khóa Ngành',
            'id_khoa': 'Khóa Học',
            'id_nganh': 'Ngành Học',
                    } 

class LopHocForm(ModelForm):
    class Meta:
        model = LopHoc
        fields = '__all__'
        labels ={
            'ten_khoa_nganh': 'Tên Khóa Ngành',
            'class_name': 'Lớp Học',
                    }       
class LopHocUpdateForm(ModelForm):
    class Meta:
        model = LopHoc
        fields = '__all__'
        # exclude= ('ten_khoa_nganh',)
        labels ={
            'ten_khoa_nganh': 'Tên Khóa Ngành',
            'class_name': 'Lớp Học',
                    }   

class SchoolYearForm(ModelForm):
    class Meta:
        model = SchoolYear
        fields = '__all__'
        labels ={
            'so_khoa': 'Số Khóa',
                    }

class MajorForm(ModelForm):
    class Meta:
        model = Major
        fields = '__all__'
        labels ={
            'ten_nganh': 'Tên Ngành',
                    }
