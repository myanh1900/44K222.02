from django.shortcuts import render
from django.views.generic import ListView, DetailView

from .models import SchoolYear, Major, SubjectMajor, SchoolYearMajor, LopHoc, EducationProgram
from .forms import EducationProgramForm, LopHocUpdateForm, EducationProgramUpdateForm, SubjectMajorForm, SchoolYearMajorForm, LopHocForm, SubjectMajorUpdateForm, SchoolYearMajorUpdateForm

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from django.contrib.auth.mixins import LoginRequiredMixin

class SchoolYearListView(ListView):
    model = SchoolYear
    template_name = 'schoolyear_list.html'

class MajorListView(ListView):
    model = Major
    template_name = 'major_list.html'

class SubjectMajorListView(ListView):
    model = SubjectMajor
    template_name = 'subjectmajor_list.html'
class SubjectMajorDetailView(DetailView):
    model = SubjectMajor
    template_name = 'subjectmajor_detail.html'
class SubjectMajorCreate(LoginRequiredMixin, CreateView):
    model = SubjectMajor
    form_class = SubjectMajorForm
    template_name = 'subjectmajor_form.html'
class SubjectMajorUpdate(LoginRequiredMixin, UpdateView):
    model = SubjectMajor
    form_class = SubjectMajorUpdateForm
    template_name = 'subjectmajor_update_form.html'

class SchoolYearMajorListView(ListView):
    model = SchoolYearMajor
    template_name = 'schoolyearmajor_list.html'
class SchoolYearMajorDetailView(DetailView):
    model = SchoolYearMajor
    template_name = 'schoolyearmajor_detail.html'
class SchoolYearMajorCreate(LoginRequiredMixin, CreateView):
    model = SchoolYearMajor
    form_class = SchoolYearMajorForm
    template_name = 'schoolyearmajor_form.html'
class SchoolYearMajorUpdate(LoginRequiredMixin, UpdateView):
    model = SchoolYearMajor
    form_class = SchoolYearMajorUpdateForm
    template_name = 'schoolyearmajor_update_form.html'

class LopHocListView(ListView):
    model = LopHoc
    template_name = 'class_list.html'  
class LopHocDetailView(DetailView):
    model = LopHoc
    template_name = 'class_detail.html'
class LopHocCreate(LoginRequiredMixin, CreateView):
    model = LopHoc
    form_class = LopHocForm
    template_name = 'class_form.html'
class LopHocUpdate(LoginRequiredMixin, UpdateView):
    model = LopHoc
    form_class = LopHocUpdateForm
    template_name = 'class_update_form.html'

class EducationProgramListView(ListView):
    model = EducationProgram
    template_name = 'educationprogram_list.html'
class EducationProgramDetailView(DetailView):
    model = EducationProgram
    template_name = 'educationprogram_detail.html'
class EducationProgramCreate(LoginRequiredMixin, CreateView):
    model = EducationProgram
    form_class = EducationProgramForm
    template_name = 'educationprogram_form.html'
class EducationProgramUpdate(LoginRequiredMixin, UpdateView):
    model = EducationProgram
    form_class = EducationProgramUpdateForm
    template_name = 'educationprogram_update_form.html'
