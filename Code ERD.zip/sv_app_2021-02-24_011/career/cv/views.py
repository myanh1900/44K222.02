from django.shortcuts import render
from django.views.generic import ListView, DetailView

from .models import Contact, Education, SocialExperience, WorkExperience, Skill, Language, Interest, Goal
from .forms import InterestForm, InterestUpdateForm, ContactForm, ContactUpdateForm, SkillUpdateForm, LanguageUpdateForm, WorkExperienceUpdateForm, LanguageForm, SocialExperienceUpdateForm, EducationUpdateForm, EducationForm, SocialExperienceForm, WorkExperienceForm, SkillForm

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from django.contrib.auth.mixins import LoginRequiredMixin

class GoalDetailView(DetailView):
    model = Goal
    template_name = 'goal_detail.html'

class InterestListView(ListView):
    model = Interest
    template_name = 'interest_list.html'
class InterestDetailView(DetailView):
    model = Interest
    template_name = 'interest_detail.html'
class InterestCreate(LoginRequiredMixin, CreateView):
    model = Interest
    form_class = InterestForm
    template_name = 'interest_form.html'
class InterestUpdate(LoginRequiredMixin, UpdateView):
    model = Interest
    form_class = InterestUpdateForm
    template_name = 'interest_update_form.html'

class ContactListView(ListView):
    model = Contact
    template_name = 'contact_list.html'
class ContactDetailView(DetailView):
    model = Contact
    template_name = 'contact_detail.html'
class ContactCreate(LoginRequiredMixin, CreateView):
    model = Contact
    form_class = ContactForm
    template_name = 'contact_form.html'
class ContactUpdate(LoginRequiredMixin, UpdateView):
    model = Contact
    form_class = ContactUpdateForm
    template_name = 'contact_update_form.html'


class LanguageListView(ListView):
    model = Language
    template_name = 'language_list.html'   
class LanguageDetailView(DetailView):
    model = Language
    template_name = 'language_list_detail.html'
class LanguageCreate(LoginRequiredMixin, CreateView):
    model = Language
    form_class = LanguageForm
    template_name = 'language_list_form.html'
class LanguageUpdate(LoginRequiredMixin, UpdateView):
    model = Language
    form_class = LanguageUpdateForm
    template_name = 'language_list_update_form.html'

class EducationListView(ListView):
    model = Education
    template_name = 'education_list.html'
class EducationDetailView(DetailView):
    model = Education
    template_name = 'education_detail.html'
class EducationCreate(LoginRequiredMixin, CreateView):
    model = Education
    form_class = EducationForm
    template_name = 'education_form.html'
class EducationUpdate(LoginRequiredMixin, UpdateView):
    model = Education
    form_class = EducationUpdateForm
    template_name = 'education_update_form.html'

class SocialExperienceListView(ListView):
    model = SocialExperience
    template_name = 'socialexp_list.html'
class SocialExperienceDetailView(DetailView):
    model = SocialExperience
    template_name = 'socialexp_detail.html'
class SocialExperienceCreate(LoginRequiredMixin, CreateView):
    model = SocialExperience
    form_class = SocialExperienceForm
    template_name = 'socialexp_form.html'
class SocialExperienceUpdate(LoginRequiredMixin, UpdateView):
    model = SocialExperience
    form_class = SocialExperienceUpdateForm
    template_name = 'socialexp_update_form.html'

class WorkExperienceListView(ListView):
    model = WorkExperience
    template_name = 'workexp_list.html'
class WorkExperienceDetailView(DetailView):
    model = WorkExperience
    template_name = 'workexp_detail.html'
class WorkExperienceCreate(LoginRequiredMixin, CreateView):
    model = WorkExperience
    form_class = WorkExperienceForm
    template_name = 'workexp_form.html'
class WorkExperienceUpdate(LoginRequiredMixin, UpdateView):
    model = WorkExperience
    form_class = WorkExperienceUpdateForm
    template_name = 'workexp_update_form.html'

class SkillListView(ListView):
    model = Skill
    template_name = 'skill_list.html'
class SkillDetailView(DetailView):
    model = Skill
    template_name = 'skill_detail.html'
class SkillCreate(LoginRequiredMixin, CreateView):
    model = Skill
    form_class = SkillForm
    template_name = 'skill_form.html'
class SkillUpdate(LoginRequiredMixin, UpdateView):
    model = Skill
    form_class = SkillUpdateForm
    template_name = 'skill_update_form.html'


