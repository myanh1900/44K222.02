from django.forms import ModelForm

from .models import Contact, Education, SocialExperience, WorkExperience, Skill, Language, Interest, Goal

class InterestForm(ModelForm):
    class Meta:
        model = Interest
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'so_thich': 'Tên Kỹ Năng',
                    }

class GoalForm(ModelForm):
    class Meta:
        model = Goal
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'muc_tieu': 'Mục Tiêu Nghề Nghiệp',
                    }


class InterestUpdateForm(ModelForm):
    class Meta:
        model = Interest
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'so_thich': 'Tên Kỹ Năng',
                    }

class LanguageForm(ModelForm):
    class Meta:
        model = Language
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'ten_ngoai_ngu': 'Tên Kỹ Năng',
            'muc_do': 'Mức Độ',
                    }

class LanguageUpdateForm(ModelForm):
    class Meta:
        model = Language
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'ten_ngoai_ngu': 'Tên Kỹ Năng',
            'muc_do': 'Mức Độ',
                    }
class ContactForm(ModelForm):
    class Meta:
        model = Contact
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'ngay_sinh': 'Ngày Sinh',
            'gioi_tinh': 'Giới Tính',
            'so_dien_thoai': 'Số Điện Thoại',
            'dia_chi': 'Địa Chỉ',
            'facebook_url': 'URL Facebook',
            'linkedin_url': 'URL LinkedIn',
            'email': 'Email',
                    }
class ContactUpdateForm(ModelForm):
    class Meta:
        model = Contact
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'ngay_sinh': 'Ngày Sinh',
            'gioi_tinh': 'Giới Tính',
            'so_dien_thoai': 'Số Điện Thoại',
            'dia_chi': 'Địa Chỉ',
            'facebook_url': 'URL Facebook',
            'linkedin_url': 'URL LinkedIn',
            'email': 'Email',
                    }

class EducationForm(ModelForm):
    class Meta:
        model = Education
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'truong_hoc': 'Tên Trường Học',
            'tg_bat_dau': 'Thời Gian Bắt Đầu',
            'tg_ket_thuc': 'Thời Gian Kết Thúc',
            'chuc_vu': 'Chức Vụ',
            'loai_bang_cap': 'Loại Bằng Cấp',
                    }
class EducationUpdateForm(ModelForm):
    class Meta:
        model = Education
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'truong_hoc': 'Tên Trường Học',
            'tg_bat_dau': 'Thời Gian Bắt Đầu',
            'tg_ket_thuc': 'Thời Gian Kết Thúc',
            'chuc_vu': 'Chức Vụ',
            'loai_bang_cap': 'Loại Bằng Cấp',
                    }

class SocialExperienceForm(ModelForm):
    class Meta:
        model = SocialExperience
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'noi_lam_viec': 'Nơi Làm Việc',
            'tg_bat_dau': 'Thời Gian Bắt Đầu',
            'tg_ket_thuc': 'Thời Gian Kết Thúc',
            'chuc_vu': 'Chức Vụ',
            'co_chung_nhan': 'Có Chứng Nhận Hay Không?',
                    }
class SocialExperienceUpdateForm(ModelForm):
    class Meta:
        model = SocialExperience
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'noi_lam_viec': 'Nơi Làm Việc',
            'tg_bat_dau': 'Thời Gian Bắt Đầu',
            'tg_ket_thuc': 'Thời Gian Kết Thúc',
            'chuc_vu': 'Chức Vụ',
            'hoat_dong': 'Mô Tả Việc Làm',
                    }

class WorkExperienceForm(ModelForm):
    class Meta:
        model = WorkExperience
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'noi_lam_viec': 'Nơi Làm Việc',
            'tg_bat_dau': 'Thời Gian Bắt Đầu',
            'tg_ket_thuc': 'Thời Gian Kết Thúc',
            'chuc_vu': 'Chức Vụ',
                    }
class WorkExperienceUpdateForm(ModelForm):
    class Meta:
        model = WorkExperience
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'noi_lam_viec': 'Nơi Làm Việc',
            'tg_bat_dau': 'Thời Gian Bắt Đầu',
            'tg_ket_thuc': 'Thời Gian Kết Thúc',
            'chuc_vu': 'Chức Vụ',
                    }

class SkillForm(ModelForm):
    class Meta:
        model = Skill
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'ten_ky_nang': 'Tên Kỹ Năng',
            'muc_do': 'Mức Độ',
                    }
class SkillUpdateForm(ModelForm):
    class Meta:
        model = Skill
        fields = '__all__'
        labels ={
            'ma_sv' : 'Mã Sinh  Viên',
            'ten_ky_nang': 'Tên Kỹ Năng',
            'muc_do': 'Mức Độ',
                    }
