from django.db import models
from django.urls import reverse
from account.models import SinhVien
# Create your models here.

# Liên Hệ
class Contact(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    ngay_sinh = models.DateField(null=True,blank=True)
    gioi_tinh = models.CharField(
        max_length=1,
        choices=[
            ('m', 'Nam'),
            ('f', 'Nữ'),
            ('o', 'Khác'),
        ],
        default='',
    )
    so_dien_thoai = models.PositiveIntegerField(null=True,blank=True)
    dia_chi = models.CharField(max_length=255,null=True,blank=True)
    facebook_url = models.URLField(null=True,blank=True)
    linkedin_url = models.URLField(null=True,blank=True)
    email =  models.EmailField(null=True,blank=True)

    def __str__(self):
        return self.dia_chi

    def get_absolute_url(self):
        return reverse("contact-detail", kwargs={"pk": self.pk})

# Học vấn
class Education(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    truong_hoc = models.CharField(max_length=255,null=True,blank=True)
    chuc_vu = models.CharField(max_length=255,null=True,blank=True)
    tg_bat_dau = models.DateField(null=True,blank=True)
    tg_ket_thuc = models.DateField(null=True,blank=True)
    loai_bang_cap = models.CharField(
        max_length=3,
        choices=[
            ('xs', 'Xuất sắc'),
            ('g', 'Giỏi'),
            ('k', 'Khá'),
            ('tb', 'Trung Bình'),
            ('y', 'Yếu'),
        ],
        default='',
    )
    def __str__(self):
        return self.truong_hoc
    def get_absolute_url(self):
        return reverse("education-detail", kwargs={"pk": self.pk})

# kinh nghiệm xã hội
class SocialExperience(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    noi_lam_viec = models.CharField(max_length=255,null=True,blank=True)
    chuc_vu = models.CharField(max_length=255,null=True,blank=True)
    tg_bat_dau = models.DateField(null=True,blank=True)
    tg_ket_thuc = models.DateField(null=True,blank=True)
    co_chung_nhan = models.CharField(
        max_length=1,
        choices=[
            ('y', 'Có'),
            ('n', 'Không'),
        ],
        default='',
    )
    def __str__(self):
        return self.noi_lam_viec
    def get_absolute_url(self):
        return reverse("socialexperience-detail", kwargs={"pk": self.pk})

# Kinh nghiệm làm việc
class WorkExperience(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    noi_lam_viec = models.CharField(max_length=255,null=True,blank=True)
    chuc_vu = models.CharField(max_length=255,null=True,blank=True)
    tg_bat_dau = models.DateField(null=True,blank=True)
    tg_ket_thuc = models.DateField(null=True,blank=True)
    hoat_dong = models.CharField(max_length=255,null=True,blank=True)
    def __str__(self):
        return self.noi_lam_viec
    def get_absolute_url(self):
        return reverse("workexperience-detail", kwargs={"pk": self.pk})

# Kỹ năng
class Skill(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    ten_ky_nang = models.CharField(max_length=255,null=True,blank=True)
    muc_do = models.CharField(
        max_length=2,
        choices=[
            ('1', '1'),
            ('2', '2'),
            ('3', '3'),
            ('4', '4'),
            ('5', '5'),
        ],
        default='',
    )  
    def __str__(self):
        return self.ten_ky_nang
    def get_absolute_url(self):
        return reverse("skill-detail", kwargs={"pk": self.pk})


# CV của sinh viên
class Language(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    ten_ngoai_ngu = models.CharField(max_length=255,null=True,blank=True)
    muc_do = models.CharField(
        max_length=2,
        choices=[
            ('1', '1'),
            ('2', '2'),
            ('3', '3'),
            ('4', '4'),
            ('5', '5'),
        ],
        default='',
    )  
    def __str__(self):
        return self.ten_ngoai_ngu
    def get_absolute_url(self):
        return reverse("language-detail", kwargs={"pk": self.pk})  

class Interest(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    so_thich = models.CharField(max_length=255,null=True,blank=True)
    def __str__(self):
        return self.so_thich
    def get_absolute_url(self):
        return reverse("interest-detail", kwargs={"pk": self.pk}) 

class Goal(models.Model):
    ma_sv = models.ForeignKey(SinhVien, null=True, on_delete=models.CASCADE)
    muc_tieu = models.CharField(max_length=255,null=True,blank=True)
    def __str__(self):
        return self.muc_tieu
    def get_absolute_url(self):
        return reverse("muc_tieu-detail", kwargs={"pk": self.pk})

