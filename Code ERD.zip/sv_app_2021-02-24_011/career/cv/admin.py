from django.contrib import admin
from .models import Contact, Education, SocialExperience, WorkExperience, Skill, Language, Interest, Goal
# Register your models here.
admin.site.register(Language)
admin.site.register(Contact)
admin.site.register(Skill)
admin.site.register(Education)
admin.site.register(SocialExperience)
admin.site.register(WorkExperience)
admin.site.register(Interest)
admin.site.register(Goal)