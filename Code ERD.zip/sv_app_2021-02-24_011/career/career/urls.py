"""career URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from cv.views import GoalDetailView, InterestListView, InterestDetailView, InterestCreate, InterestUpdate, LanguageListView, LanguageDetailView, LanguageCreate, LanguageUpdate, ContactUpdate, EducationUpdate, SocialExperienceUpdate, WorkExperienceUpdate, SkillUpdate, ContactListView, ContactDetailView, ContactCreate, SkillListView,  SkillDetailView, SkillCreate, EducationListView, EducationDetailView, EducationCreate, SocialExperienceListView, SocialExperienceDetailView, SocialExperienceCreate, WorkExperienceListView, WorkExperienceDetailView, WorkExperienceCreate
from transcript.views import SchoolYearListView, SubjectMajorUpdate, LopHocUpdate, EducationProgramUpdate, SchoolYearMajorUpdate, MajorListView, SubjectMajorListView, SubjectMajorDetailView, SubjectMajorCreate, SchoolYearMajorListView, SchoolYearMajorDetailView, SchoolYearMajorCreate, LopHocListView, LopHocDetailView, LopHocCreate, EducationProgramListView, EducationProgramDetailView, EducationProgramCreate
from account.views import SinhVienListView, SinhVienDetailView, SinhVienCreate, SinhVienUpdate
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),

    path('goal/<int:pk>', GoalDetailView.as_view(), name='goal-detail'),

    path('interest/', InterestListView.as_view(), name='interest-list'),
    path('interest/<int:pk>', InterestDetailView.as_view(), name='interest-detail'),
    path('interest/create/', InterestCreate.as_view(), name='interest-create'),
    path('interest/update/<int:pk>', InterestUpdate.as_view(), name='interest-update'),

    path('language/', LanguageListView.as_view(), name='language-list'),
    path('language/<int:pk>', LanguageDetailView.as_view(), name='language-detail'),
    path('language/create/', LanguageCreate.as_view(), name='language-create'),
    path('language/update/<int:pk>', LanguageUpdate.as_view(), name='language-update'),

    path('contact/', ContactListView.as_view(), name='contact-list'),
    path('contact/<int:pk>', ContactDetailView.as_view(), name='contact-detail'),
    path('contact/create/', ContactCreate.as_view(), name='contact-create'),
    path('contact/update/<int:pk>', ContactUpdate.as_view(), name='contact-update'),

    path('education/', EducationListView.as_view(), name='education-list'),
    path('education/<int:pk>', EducationDetailView.as_view(), name='education-detail'),
    path('education/create/', EducationCreate.as_view(), name='education-create'),
    path('education/update/<int:pk>', EducationUpdate.as_view(), name='education-update'),

    path('skill/', SkillListView.as_view(), name='skill-list'),
    path('skill/<int:pk>', SkillDetailView.as_view(), name='skill-detail'),
    path('skill/create/', SkillCreate.as_view(), name='skill-create'),
    path('skill/update/<int:pk>', SkillUpdate.as_view(), name='skill-update'),

    path('workexperience/', WorkExperienceListView.as_view(), name='workexperience-list'),
    path('workexperience/<int:pk>', WorkExperienceDetailView.as_view(), name='workexperience-detail'),
    path('workexperience/create/', WorkExperienceCreate.as_view(), name='workexperience-create'),
    path('workexperience/update/<int:pk>', WorkExperienceUpdate.as_view(), name='workexperience-update'),

    path('socialexperience/', SocialExperienceListView.as_view(), name='socialexp-list'),
    path('socialexperience/<int:pk>', SocialExperienceDetailView.as_view(), name='socialexperience-detail'),
    path('socialexperience/create/', SocialExperienceCreate.as_view(), name='socialexperience-create'),
    path('socialexperience/update/<int:pk>', SocialExperienceUpdate.as_view(), name='socialexperience-update'),

# App transcript
    path('schoolyear/', SchoolYearListView.as_view(), name='schoolyear-list'),
    # path('schoolyear/update/<int:pk>', SchoolYearUpdate.as_view(), name='schoolyear-update'),

    path('major/', MajorListView.as_view(), name='major-list'),
    # path('major/update/<int:pk>', MajorUpdate.as_view(), name='major-update'),

    path('subjectmajor/', SubjectMajorListView.as_view(), name='subjectmajor-list'),
    path('subjectmajor/<int:pk>', SubjectMajorDetailView.as_view(), name='subjectmajor-detail'),
    path('subjectmajor/create/', SubjectMajorCreate.as_view(), name='subjectmajor-create'),
    path('subjectmajor/update/<int:pk>', SubjectMajorUpdate.as_view(), name='subjectmajor-update'),

    path('schoolyearmajor/', SchoolYearMajorListView.as_view(), name='schoolyearmajor-list'),
    path('schoolyearmajor/<int:pk>', SchoolYearMajorDetailView.as_view(), name='schoolyearmajor-detail'),
    path('schoolyearmajor/create/', SchoolYearMajorCreate.as_view(), name='schoolyearmajor-create'),
    path('schoolyearmajor/update/<int:pk>', SchoolYearMajorUpdate.as_view(), name='schoolyearmajor-update'),

    path('class/', LopHocListView.as_view(), name='class-list'),
    path('class/detail/<int:pk>', LopHocDetailView.as_view(), name='class-detail'),
    path('class/<int:pk>', SinhVienListView.as_view(), name='sinhvien-list'),   
    path('class/create/', LopHocCreate.as_view(), name='class-create'),
    path('class/update/<int:pk>', LopHocUpdate.as_view(), name='class-update'),

    path('educationprogram/', EducationProgramListView.as_view(), name='educationprogram-list'),
    path('educationprogram/<int:pk>', EducationProgramDetailView.as_view(), name='educationprogram-detail'),
    path('educationprogram/create/', EducationProgramCreate.as_view(), name='educationprogram-create'),
    path('educationprogram/update/<int:pk>', EducationProgramUpdate.as_view(), name='educationprogram-update'),

# Account
    path('sinhvien/', SinhVienListView.as_view(), name='sinhvien-list'),
    path('sinhvien/<int:pk>', SinhVienDetailView.as_view(), name='sinhvien-detail'),
    path('sinhvien/create/', SinhVienCreate.as_view(), name='sinhvien-create'),
    path('sinhvien/update/<int:pk>', SinhVienUpdate.as_view(), name='sinhvien-update'),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
