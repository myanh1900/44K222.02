from django.contrib import admin
from .models import SinhVien
# Register your models here.
admin.site.register(SinhVien)