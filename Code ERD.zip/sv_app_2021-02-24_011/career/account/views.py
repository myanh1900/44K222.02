from django.shortcuts import render
from django.views.generic import ListView, DetailView

from .models import SinhVien
from .forms import SinhVienForm, SinhVienUpdateForm

from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy

from django.contrib.auth.mixins import LoginRequiredMixin

class SinhVienListView(ListView):
    model = SinhVien
    template_name = 'sinhvien_list.html'

class SinhVienDetailView(DetailView):
    model = SinhVien
    template_name = 'sinhvien_detail.html'

class SinhVienCreate(LoginRequiredMixin, CreateView):
    model = SinhVien
    form_class = SinhVienForm
    template_name = 'sinhvien_form.html'

class SinhVienUpdate(LoginRequiredMixin, UpdateView):
    model = SinhVien
    form_class = SinhVienUpdateForm
    template_name = 'sinhvien_update_form.html'