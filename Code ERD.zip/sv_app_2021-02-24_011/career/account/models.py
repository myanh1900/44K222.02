from django.db import models
from transcript.models import LopHoc
from django.urls import reverse

# Create your models here.
# Account
class SinhVien(models.Model):  
    ho_lot = models.CharField(max_length=255, null=True, blank=True)
    ten_sv = models.CharField(max_length=255, null=True, blank=True)
    ma_sv = models.PositiveIntegerField(null=True, blank=True)
    avatar = models.ImageField(null=True, blank=True)
    id_lop = models.ForeignKey(LopHoc, null=True, on_delete=models.CASCADE)
    def __str__(self):
        return self.ten_sv

    def get_absolute_url(self):
        return reverse("sinhvien-detail", kwargs={"pk": self.pk})


