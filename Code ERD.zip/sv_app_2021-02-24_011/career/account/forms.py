from django.forms import ModelForm

from .models import SinhVien

class SinhVienForm(ModelForm):
    class Meta:
        model = SinhVien
        fields = '__all__'
        labels ={
            'ho_lot': 'Họ Lót',
            'ten_sv': 'Tên',
            'ma_sv': 'Mã Sinh Viên',
            'id_lop': 'Lớp Học',
                    }

class SinhVienUpdateForm(ModelForm):
    class Meta:
        model = SinhVien
        fields = '__all__'
        exclude= ('ho_lot', 'ten_sv',)
        labels ={
            'ho_lot': 'Họ Lót',
            'ten_sv': 'Tên',
            'ma_sv': 'Mã Sinh Viên',
            'id_lop': 'Lớp Học',
                    }